<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests;
use Illuminate\Support\Facades\Validator;

class AdminController extends Controller
{
    public function index(){
        return view('admin.home');
    }

    public function faculty(){
        return view('admin.faculty');
    }

     public function course(){
        return view('admin.course');
    }

    public function lecturer(){
        return view('admin.lecturer');
    }

    public function period(){
        return view('admin.period');
    }

    public function timetable(){
        return view('admin.timetable');
    }

}
