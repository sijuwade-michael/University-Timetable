<?php $__env->startSection('content'); ?>

<div class="pt-0">
    <form role="form" method="POST" action="<?php echo e(url('/admin/password/reset')); ?>" class="my-4">
        <div class="form-group mb-3<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <label for="emailaddress" class="form-label">Email address</label>
            <input class="form-control" type="email" name="email" id="emailaddress" required="" placeholder="Enter your email">
            <?php if($errors->has('email')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group mb-3<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <label for="password" class="form-label">Password</label>
            <input class="form-control" type="password" name="password" required="" id="password" placeholder="Enter your password">
            <?php if($errors->has('password')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group mb-3<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
            <label for="password_confirm" class="form-label">Confirm Password</label>
            <input class="form-control" type="password" name="password_confirmation" required="" id="password" placeholder="Enter your password">
            <?php if($errors->has('password_confirmation')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                </span>
            <?php endif; ?>
        </div>


        
        <div class="form-group mb-0 row">
            <div class="col-12">
                <div class="d-grid">
                    <button class="btn btn-primary" type="submit"> Reset Password </button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\table-gen\resources\views/admin/auth/passwords/reset.blade.php ENDPATH**/ ?>