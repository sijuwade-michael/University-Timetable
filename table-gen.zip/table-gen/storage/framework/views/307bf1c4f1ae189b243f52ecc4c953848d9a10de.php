

<?php $__env->startSection('content'); ?>
 <div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">KeyTable Example Datatable</h5>
            </div><!-- end card header -->

            <div class="card-body">
                <table id="key-table" class="table table-bordered dt-responsive nowrap">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Position</th>
                            <th>Office</th>
                            <th>Age</th>
                            <th>Start date</th>
                            <th>Salary</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Your table data goes here, same as what you have already -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

 <!-- dataTables.keyTable -->
<script src="<?php echo e(asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-bs5/js/dataTables.bootstrap5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-keytable/js/dataTables.keyTable.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-keytable-bs5/js/keyTable.bootstrap5.min.js')); ?>"></script>

<script>
    $(document).ready(function() {
        // Initialize the DataTable with all features
        $('#key-table').DataTable({
            keys: true,  // Enable keyboard navigation (KeyTable functionality)
            responsive: true,  // Ensure the table is responsive
            paging: true,  // Enable pagination
            ordering: true,  // Enable column sorting
            searching: true,  // Enable search bar functionality
            pageLength: 10,  // Set the default number of rows per page
            lengthMenu: [10, 25, 50, 100],  // Set the page length options
            language: {
                search: "_INPUT_",  // Customize search placeholder text
                searchPlaceholder: "Search records...",  // Placeholder text for the search input
                paginate: {
                    next: 'Next',  // Next page button text
                    previous: 'Previous'  // Previous page button text
                }
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\table-gen\resources\views/admin/faculty.blade.php ENDPATH**/ ?>